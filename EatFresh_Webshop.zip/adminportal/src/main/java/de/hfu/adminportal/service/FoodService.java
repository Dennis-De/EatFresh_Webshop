package de.hfu.adminportal.service;

import java.util.List;

import de.hfu.adminportal.domain.Food;

public interface FoodService {
	
	Food save(Food food);
	
	List<Food> findAll();
	
	Food findOne(Long id);

}

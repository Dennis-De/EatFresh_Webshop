package de.hfu.adminportal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.hfu.adminportal.domain.Food;
import de.hfu.adminportal.repository.FoodRepository;
import de.hfu.adminportal.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService{
	
	@Autowired
	private FoodRepository foodRepository;
	
	public Food save(Food food) {
		return foodRepository.save(food);
	}
	
	public List<Food> findAll() {
		return (List<Food>) foodRepository.findAll();
	}

	public Food findOne(Long id) {
		// TODO Auto-generated method stub
		return foodRepository.findById(id).get();
	}

}

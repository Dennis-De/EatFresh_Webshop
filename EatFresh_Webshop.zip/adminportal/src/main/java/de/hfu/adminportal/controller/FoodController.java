package de.hfu.adminportal.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import de.hfu.adminportal.domain.Food;
import de.hfu.adminportal.service.FoodService;

@Controller
@RequestMapping("/food")
public class FoodController {

	@Autowired
	private FoodService foodService;

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addFood(Model model) {
		Food food = new Food();
		model.addAttribute("food", food);
		return "addFood";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addFoodPost(@ModelAttribute("food") Food food, HttpServletRequest request) {
		foodService.save(food);

		MultipartFile foodImage = food.getFoodImage();

		try {
			byte[] bytes = foodImage.getBytes();
			String name = food.getId() + ".png";
			BufferedOutputStream stream = new BufferedOutputStream(
					new FileOutputStream(new File("src/main/resources/static/image/food/" + name)));
			stream.write(bytes);
			stream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:foodList";
	}
	
	@RequestMapping("/foodInfo")
	public String foodInfo(@RequestParam("id") Long id, Model model) {
		Food food = foodService.findOne(id);
		model.addAttribute("food", food);		
		return "foodInfo";		
	}
	
	@RequestMapping("/updateFood")
	public String updateFood(@RequestParam("id") Long id, Model model) {
		Food food = foodService.findOne(id);
		model.addAttribute("food", food);	
		
		return "updateFood";		
	}
	
	@RequestMapping(value="/updateFood", method=RequestMethod.POST)
	public String updateFoodPost(@ModelAttribute("food") Food food, HttpServletRequest request) {
		foodService.save(food);
		
		MultipartFile foodImage = food.getFoodImage();
		if(!foodImage.isEmpty()){
			try {
				byte[] bytes = foodImage.getBytes();
				String name = food.getId() + ".png";
				
				Files.delete(Paths.get("src/main/resources/static/image/food/"+name));
				
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(new File("src/main/resources/static/image/food/" + name)));
				stream.write(bytes);
				stream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}			
		
		return "redirect:/food/foodInfo?id="+food.getId();		
	}
	
	@RequestMapping("/foodList")
	public String foodList(Model model) {
		List<Food> foodList = foodService.findAll();
		model.addAttribute("foodList", foodList);		
		return "foodList";
		
	}

}

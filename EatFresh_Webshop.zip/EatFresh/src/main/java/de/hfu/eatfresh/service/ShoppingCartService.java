package de.hfu.eatfresh.service;

import de.hfu.eatfresh.domain.ShoppingCart;

public interface ShoppingCartService {
	
	ShoppingCart updateShoppingCart(ShoppingCart shoppingcart);

}

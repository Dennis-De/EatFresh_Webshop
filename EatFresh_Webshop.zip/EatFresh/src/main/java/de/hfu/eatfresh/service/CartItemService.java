package de.hfu.eatfresh.service;

import java.util.List;

import de.hfu.eatfresh.domain.CartItem;
import de.hfu.eatfresh.domain.Food;
import de.hfu.eatfresh.domain.ShoppingCart;
import de.hfu.eatfresh.domain.User;

public interface CartItemService {
	List<CartItem> findByShoppingCart(ShoppingCart shoppingCart);
	
	CartItem updateCartItem(CartItem cartItem);
	
	CartItem addFoodToCartItem(Food food, User user, int qty);
	
	CartItem findById(Long id);
	
	void removeCartItem(CartItem cartItem);

}

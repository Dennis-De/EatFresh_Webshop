package de.hfu.eatfresh.repository;


import org.springframework.data.repository.CrudRepository;

import de.hfu.eatfresh.domain.Food;

public interface FoodRepository extends CrudRepository<Food, Long>{

}

package de.hfu.eatfresh.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.hfu.eatfresh.domain.Food;
import de.hfu.eatfresh.repository.FoodRepository;
import de.hfu.eatfresh.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService{
	@Autowired
	private FoodRepository foodRepository;
	
	public List<Food> findAll() {
		return (List<Food>) foodRepository.findAll();
	}
	
	public Food findOne(Long id) {
		return foodRepository.findById(id).get();
	}

}

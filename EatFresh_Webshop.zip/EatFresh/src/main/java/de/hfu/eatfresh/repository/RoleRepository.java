package de.hfu.eatfresh.repository;

import org.springframework.data.repository.CrudRepository;

import de.hfu.eatfresh.domain.security.Role;

public interface RoleRepository extends CrudRepository<Role, Long> {
	Role findByname(String name);
}

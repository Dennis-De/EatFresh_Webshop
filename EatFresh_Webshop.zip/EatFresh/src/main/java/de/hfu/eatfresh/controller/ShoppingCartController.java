package de.hfu.eatfresh.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import de.hfu.eatfresh.domain.CartItem;
import de.hfu.eatfresh.domain.Food;
import de.hfu.eatfresh.domain.ShoppingCart;
import de.hfu.eatfresh.domain.User;
import de.hfu.eatfresh.service.CartItemService;
import de.hfu.eatfresh.service.FoodService;
import de.hfu.eatfresh.service.ShoppingCartService;
import de.hfu.eatfresh.service.UserService;

@Controller
@RequestMapping("/shoppingCart")
public class ShoppingCartController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartItemService cartItemService;
	
	@Autowired
	private FoodService foodService;
	
	@Autowired
	private ShoppingCartService shoppingCartService;
	
	@RequestMapping("/cart")
	public String shoppingCart(Model model, Principal principal) {
		User user = userService.findByUsername(principal.getName());
		ShoppingCart shoppingCart = user.getShoppingCart();
		
		List<CartItem> cartItemList = cartItemService.findByShoppingCart(shoppingCart);
		
		shoppingCartService.updateShoppingCart(shoppingCart);
		
		model.addAttribute("cartItemList", cartItemList);
		model.addAttribute("shoppingCart", shoppingCart);
		
		return "shoppingCart";
	}
	
	@RequestMapping("/addItem")
	public String addItem(
			@ModelAttribute("food") Food food,
			@ModelAttribute("qty") String qty,
			Model model, Principal principal
			) {
		User user = userService.findByUsername(principal.getName());
		food = foodService.findOne(food.getId());
		
		if (Integer.parseInt(qty) > food.getInStockNumber()) {
			model.addAttribute("notEnoughStock", true);
			return "forward:/foodDetail?id="+food.getId();
		}
		
		CartItem cartItem = cartItemService.addFoodToCartItem(food, user, Integer.parseInt(qty));
		model.addAttribute("addFoodSuccess", true);
		
		return "forward:/foodDetail?id="+food.getId();		
	}
	
	@RequestMapping("/updateCartItem")
	public String updateShoppingCart(
			@ModelAttribute("id") Long cartItemId,
			@ModelAttribute("qty") int qty
			) {
		CartItem cartItem = cartItemService.findById(cartItemId);
		cartItem.setQty(qty);
		cartItemService.updateCartItem(cartItem);
		
		return "forward:/shoppingCart/cart";
	}
	
	@RequestMapping("/removeItem")
	public String removeItem(@RequestParam("id") Long id) {
		cartItemService.removeCartItem(cartItemService.findById(id));
		
		return "forward:/shoppingCart/cart"; 
	}

}

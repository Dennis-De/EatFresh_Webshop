package de.hfu.eatfresh.repository;

import org.springframework.data.repository.CrudRepository;

import de.hfu.eatfresh.domain.UserShipping;

public interface UserShippingRepository extends CrudRepository<UserShipping, Long> {
	
	

}

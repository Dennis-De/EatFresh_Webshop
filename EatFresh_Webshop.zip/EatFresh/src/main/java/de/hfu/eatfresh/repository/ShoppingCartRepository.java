package de.hfu.eatfresh.repository;

import org.springframework.data.repository.CrudRepository;

import de.hfu.eatfresh.domain.ShoppingCart;

public interface ShoppingCartRepository extends CrudRepository<ShoppingCart, Long>{

}

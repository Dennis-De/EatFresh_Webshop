package de.hfu.eatfresh.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import de.hfu.eatfresh.domain.CartItem;
import de.hfu.eatfresh.domain.FoodToCartItem;

@Transactional
public interface FoodToCartItemRepository extends CrudRepository<FoodToCartItem, Long>{
	
	void deleteByCartItem(CartItem cartItem);

}

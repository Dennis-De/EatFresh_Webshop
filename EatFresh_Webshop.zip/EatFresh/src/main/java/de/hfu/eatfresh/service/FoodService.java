package de.hfu.eatfresh.service;

import java.util.List;

import de.hfu.eatfresh.domain.Food;

public interface FoodService {
	List<Food> findAll ();
	
	Food findOne(Long id);
}
